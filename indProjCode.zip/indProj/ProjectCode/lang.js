function setLanguage() {
    const selectedLanguage = document.getElementById('lang').value;
    localStorage.setItem('language', selectedLanguage);
    
    // Trigger the onchange event of the lang dropdown to navigate to the selected language page
    const langDropdown = document.getElementById('lang');
    langDropdown.onchange();
  }
  
  // Attach event listener to the lang dropdown menu
  const langDropdown = document.getElementById('lang');
  langDropdown.addEventListener('change', setLanguage);
  
  // Check local storage for language preference when the page loads
  const savedLanguage = localStorage.getItem('language');
  if (savedLanguage) {
    langDropdown.value = savedLanguage;
  } else {
    // If no language preference is saved, default to English
    langDropdown.value = 'index.html';
    // Trigger the default language onchange event to navigate to the default language page
    langDropdown.onchange();
  }
  
  