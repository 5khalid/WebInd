// like functionality 

// Retrieve the like count from localStorage
let lCount = localStorage.getItem('likeCount');

// Get the like button and like count elements
const likeButton = document.getElementById('like');
const likeCount = document.getElementById('likeCount');

// If there is a saved like count, update the like count element with it
if (lCount) {
  likeCount.textContent = lCount;
}

// Add a click event listener to the like button
likeButton.addEventListener('click', function likeArticle() {
  // Increment the like count
  let count = parseInt(likeCount.textContent);
  count++;
  
  // Update the like count element with the new count
  likeCount.textContent = count.toString();
  document.getElementById('likeCount').innerHTML = count;

  // Save the updated like count to localStorage
  localStorage.setItem('likeCount', count.toString());
});











