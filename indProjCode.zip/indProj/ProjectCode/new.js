//froala editor 

document.addEventListener("DOMContentLoaded", function initForm() {
  // Initialize Froala editors
  var editor1 = new FroalaEditor("#content", {});
  var editor2 = new FroalaEditor("#arabic-content", {});

  // Set "title" textarea to required
  // var titleTextarea = document.querySelector("#title");
  // titleTextarea.required = true;

  // Add validation check
  document.querySelector('form').addEventListener('submit', function(event) {
    var content = editor1.html.get().trim();
    if (content && content.length >= 17) {
      // All input elements have a value and content has at least 17 non-white space characters
      alert('Form submitted successfully');
    } else {
      event.preventDefault();
      // Content is empty or has less than 10 non-white space characters
      alert('Please make sure content has at least 10 non-white space characters');
    }
  });

});

//   
// });

