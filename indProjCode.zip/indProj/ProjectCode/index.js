  //article deletion 

  function deleteArticle(event) {
    const confirmDelete = confirm("Are you sure you want to delete this article?");
    if (confirmDelete) {
      const articleDiv = event.target.closest(".articles");
      if (articleDiv) {
        articleDiv.remove();
      }
    }
  }


  function deleteArticle() {
    var articles = document.getElementsByClassName("articles");
    for (var i = 0; i < articles.length; i++) {
      articles[i].querySelector("#delete").addEventListener("click", function() {
        if (confirm("Are you sure you want to delete this article?")) {
          this.closest(".articles").remove();
        }
      });
    }
  }
  deleteArticle();